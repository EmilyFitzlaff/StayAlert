<header>
    <div class="collapse bg" style="background-color: #FE6D73;" id="navbarHeader">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 col-md-7 py-4">
                    <h4 class="text-white">StayAlert</h4>
                    <p class="text-white">Sistema para alertar a população sobre o desaparencimento de pessoas.</p>
                </div>
                <div class="col-sm-4 offset-md-1 py-4">
                    <h4 class="text-white">Contato</h4>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-white">juliafitzlaff@gmail.com</a></li>
                        <li><a href="#" class="text-white">milenamazzini@gmail.com</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="navbar navbar-dark bg shadow-sm" style="background-color: #FE6D73;">
        <div class="container">
            <a href="index.php" class="navbar-brand d-flex align-items-center">
                StayAlert
            </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
        </div>
    </div>
</header>