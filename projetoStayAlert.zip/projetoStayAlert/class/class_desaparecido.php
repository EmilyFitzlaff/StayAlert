<?php

    Class Desaparecido {

    }
?>