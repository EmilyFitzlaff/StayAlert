<footer class="text-muted py-5">
    <div class="container">
        <p class="float-end mb-1">
        <a href="#">Voltar ao início</a>
        </p>
        <p class="mb-1">&copy; Todos os Direitos Reservados.</p>
        <p class="mb-0">Elaborado por: <a href="/">Julia da Silva Fitzlaff</a> e <a href="/docs/5.0/getting-started/introduction/">Milena Mazzini</a>.</p>
    </div>
</footer>

<script src="/docs/5.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>